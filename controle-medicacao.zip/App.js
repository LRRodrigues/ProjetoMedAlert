import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, Alert, TouchableOpacity, Image, StyleSheet } from 'react-native';

export default function App() {
  const [meds, setMeds] = useState([]);
  const [medName, setMedName] = useState('');
  const [medTime, setMedTime] = useState('');
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const timeString = now.toTimeString().slice(0, 5);
      setCurrentTime(timeString);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    meds.forEach((med) => {
      if (med.time === currentTime && !med.taken) {
        Alert.alert('Hora do Remédio', `Hora de tomar: ${med.name}`);
      }
    });
  }, [currentTime]);

  const addMed = () => {
    if (medName && medTime) {
      setMeds([...meds, { name: medName, time: medTime, taken: false }]);
      setMedName('');
      setMedTime('');
    }
  };

  const markAsTaken = (index) => {
    const updatedMeds = [...meds];
    updatedMeds[index].taken = true;
    setMeds(updatedMeds);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Controle de Medicação</Text>
      <TextInput style={styles.input} placeholder="Nome do remédio" value={medName} onChangeText={setMedName} />
      <TextInput style={styles.input} placeholder="Horário (HH:MM)" value={medTime} onChangeText={setMedTime} />
      <Button title="Adicionar Medicação" onPress={addMed} />

      <FlatList
        data={meds}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item, index }) => (
          <View style={styles.medItem}>
            <Text style={{ flex: 1 }}>{item.name} - {item.time} - {item.taken ? "Tomado" : "Pendente"}</Text>
            <TouchableOpacity onPress={() => markAsTaken(index)}>
              <Image source={require('./assets/taken-icon.png')} style={styles.icon} />
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, paddingTop: 50 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  input: { borderWidth: 1, borderColor: '#ccc', padding: 10, marginVertical: 5 },
  medItem: { flexDirection: 'row', alignItems: 'center', marginTop: 10 },
  icon: { width: 30, height: 30 },
});