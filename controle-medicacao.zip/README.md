# 💊 Controle de Medicação

Aplicativo desenvolvido em **React Native com Expo** para controle de medicamentos.

## Funcionalidades

- Cadastro de medicamentos com nome e horário
- Alerta na hora do medicamento
- Marcar como administrado
- Lista de medicamentos

## Como rodar

```bash
npm install
npm start
```

Use o app [Expo Go](https://expo.dev/client) no seu celular para testar.